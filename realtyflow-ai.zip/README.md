
# RealtyFlow AI 🚀

Dette er den profesjonelle kildekoden for **RealtyFlow AI**, din intelligente salgsassistent for det spanske boligmarkedet.

## 🔗 Repository Info
- **GitHub:** [https://github.com/freddybremseth-coder/RealtyFlowAI](https://github.com/freddybremseth-coder/RealtyFlowAI)
- **Utviklet for:** Freddy Bremseth / Zen Eco Homes

## 🛠 Hvordan koble til riktig Repository i AI Studio

Hvis "Sync to GitHub"-knappen peker på feil sted:
1. Klikk på **"Sync to GitHub"** i den øverste linjen i AI Studio.
2. I panelet som åpnes, klikk på navnet til det nåværende repository-et.
3. Velg **"Disconnect"** eller **"Switch Repository"**.
4. Velg `freddybremseth-coder/RealtyFlowAI` fra listen din.

---
*Denne koden er beskyttet og konfigurert for Freddy Bremseth.*
